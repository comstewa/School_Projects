Connor Stewart
Comstewa
README
PA4

I used my graph from pa3 and simply added to it. This time no / on line 14 though lmao.
README:  list of files and stuff
Makefile:    provided  compiles my stuff
List.c:    same one from all teh prev assigments
List.h:	  same
Graph.c:   modified to add a dfs
Graph.h:    added some functions
GraphTest.c	-	very simple test client
FindComponents.c:  main client
