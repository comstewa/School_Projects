README LAB#1 CSE101 
Comstewa #1601796
List.h header file for List.c declares most of the functions for List
List.c Creates the functions declared in the header. This fill is used by listcluient aswell as Lex.c. It is a basic double linked list with some added functions.
ListClient.c provided on webpage to test the code
Lex.c A simple sort that sorts an input file alphabeticly into an output file
Makefile compiles the code
README table of contents.